package app.thecity.model;

import java.io.Serializable;

public class Category implements Serializable {
    public int cat_id;
    public String name;
    public int icon;
}
