package app.thecity.connection.callbacks;

import java.io.Serializable;

import app.thecity.model.Place;

public class CallbackPlaceDetails implements Serializable {

    public Place place = null;

}
