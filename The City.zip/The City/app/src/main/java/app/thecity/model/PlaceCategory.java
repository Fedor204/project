package app.thecity.model;

import java.io.Serializable;

public class PlaceCategory implements Serializable {
    public int place_id;
    public int cat_id;
}
